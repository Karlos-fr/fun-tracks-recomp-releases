#!/bin/bash
# Fun Tracks recomp, port PortMaster (docs/LINUX_HANDHELD_PLAN.md).
# Les fichiers du jeu d'origine (fournis par le joueur) vont dans ports/funtracks/gamedata/.

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/funtracks"
DATADIR="$GAMEDIR/gamedata"
cd "$GAMEDIR"
> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

# Fichiers du jeu absents : le dire au lieu d'un écran noir.
if [ ! -d "$DATADIR" ] || [ -z "$(find "$DATADIR" -maxdepth 1 -type d -iname 'levels' -print -quit)" ]; then
  pm_message "Copy the files of your Fun Tracks install folder into ports/funtracks/gamedata/ (see README.md)."
  sleep 8
  pm_finish
  exit 1
fi

# Réglages de départ (moteur logiciel, sûr sur toutes les consoles) au premier lancement ; le jeu
# complète les clés absentes et garde ensuite les choix du joueur.
if [ ! -f "$DATADIR/fun_tracks_recomp.ini" ]; then
  cp "$GAMEDIR/fun_tracks_recomp.ini" "$DATADIR/fun_tracks_recomp.ini"
fi

export SDL_GAMECONTROLLERCONFIG="$sdl_controllerconfig"

# gptokeyb : seulement la combinaison de sortie ; la manette est lue par le jeu (SDL3).
$GPTOKEYB "funtracks.${DEVICE_ARCH}" &
pm_platform_helper "$GAMEDIR/funtracks.${DEVICE_ARCH}"

# Le jeu lit ses fichiers et ses réglages dans le dossier courant.
cd "$DATADIR"
"$GAMEDIR/funtracks.${DEVICE_ARCH}"

pm_finish
